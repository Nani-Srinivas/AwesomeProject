import React, { useState, useEffect } from 'react'; // Import useEffect
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS } from '../../constants/colors';
import { Button } from '../../components/common/Button';

import { useUserStore } from '../../store/userStore';

interface LoginScreenProps {
  navigation: any;
}

export const LoginScreen = ({ navigation }: LoginScreenProps) => {
  const [email, setEmail] = useState('test@example.com');
  const [password, setPassword] = useState('password');
  const [loading, setLoading] = useState(false);
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const { setAuthToken, setUser } = useUserStore();

  useEffect(() => {
    const abortController = new AbortController();
    return () => {
      abortController.abort(); // Cancel ongoing requests when component unmounts
    };
  }, []);

  const handleLogin = async () => {
    setEmailError('');
    setPasswordError('');

    // Basic validation
    let isValid = true;
    if (!email) {
      setEmailError('Email is required');
      isValid = false;
    }
    else if (!/\S+@\S+\.\S+/.test(email)) {
      setEmailError('Invalid email format');
      isValid = false;
    }

    if (!password) {
      setPasswordError('Password is required');
      isValid = false;
    }
    else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      isValid = false;
    }

    if (!isValid) {
      return;
    }

    setLoading(true);
    const abortController = new AbortController(); // Create a new AbortController for each login attempt
    try {
      // Simulate API call (pass signal here if it were a real apiService call)
      // await apiService.post('/login', { email, password }, abortController.signal);
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate with delay

      if (email === 'test@example.com' && password === 'password') {
        const dummyToken = 'dummy-production-ready-auth-token';
        const user = { name: 'Test User' };

        setUser(user);
        setAuthToken(dummyToken);
        Alert.alert('Success', 'Logged in successfully!');
      } else {
        Alert.alert('Error', 'Invalid credentials');
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.log('Request aborted');
        return; // Do nothing if the request was intentionally aborted
      }
      // Specific error handling for login
      if (error.response && error.response.status === 401) {
        Alert.alert('Login Failed', 'Incorrect email or password.');
      } else if (error.message === 'Network Error') {
        Alert.alert('Network Issue', 'Please check your internet connection and try again.');
      } else {
        Alert.alert('Login Error', error.message || 'An unexpected error occurred during login.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <Text style={styles.title}>Welcome Back!</Text>
        <Text style={styles.subtitle}>Login to continue</Text>

        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor={COLORS.text}
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />
        {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}          
        <TextInput
          style={styles.input}
          placeholder="Password"
          placeholderTextColor={COLORS.text}
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />
        {passwordError ? <Text style={styles.errorText}>{passwordError}</Text> : null}

        <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
          <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
        </TouchableOpacity>

        <Button title={loading ? 'Logging In...' : 'Login'} onPress={handleLogin} />

        <View style={styles.signUpContainer}>
          <Text style={styles.signUpText}>Don't have an account? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={styles.signUpLink}>Sign Up</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: COLORS.text,
    marginBottom: 40,
  },
  input: {
    width: '100%',
    height: 50,
    borderColor: COLORS.primary,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 15,
    color: COLORS.text,
    backgroundColor: COLORS.background,
  },
  forgotPasswordText: {
    color: COLORS.primary,
    marginBottom: 20,
    alignSelf: 'flex-end',
  },
  errorText: {
    color: 'red',
    alignSelf: 'flex-start',
    marginBottom: 10,
    marginLeft: 5,
  },
  signUpContainer: {
    flexDirection: 'row',
    marginTop: 30,
  },
  signUpText: {
    color: COLORS.text,
  },
  signUpLink: {
    color: COLORS.primary,
    fontWeight: 'bold',
  },
});
