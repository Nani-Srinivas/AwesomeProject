// import React, { useState, useMemo } from 'react';
// import { View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput, Alert, ScrollView } from 'react-native';
// import { SafeAreaView } from 'react-native-safe-area-context';
// import { COLORS } from '../../constants/colors';
// import { MainStackParamList } from '../../navigation/types';
// import { NativeStackScreenProps } from '@react-navigation/native-stack';
// import Feather from 'react-native-vector-icons/Feather';

// type BillsScreenProps = NativeStackScreenProps<MainStackParamList, 'Bills'>;

// interface Customer {
//   name: string;
//   id: string;
//   contact: string;
//   status: 'Paid' | 'Unpaid' | 'Pending';
// }

// const DUMMY_CUSTOMERS: Customer[] = [
//   {
//     name: 'Alice Smith',
//     id: '#CST001',
//     contact: '+1 123-456-7890',
//     status: 'Paid',
//   },
//   {
//     name: 'Bob Johnson',
//     id: '#CST002',
//     contact: '+1 234-567-8901',
//     status: 'Unpaid',
//   },
//   {
//     name: 'Charlie Brown',
//     id: '#CST003',
//     contact: '+1 345-678-9012',
//     status: 'Pending',
//   },
//   {
//     name: 'Diana Prince',
//     id: '#CST004',
//     contact: '+1 456-789-0123',
//     status: 'Paid',
//   },
//   {
//     name: 'Eve Adams',
//     id: '#CST005',
//     contact: '+1 567-890-1234',
//     status: 'Unpaid',
//   },
// ];

// // Helper function for status color (replicated from CustomerListScreen)
// const getStatusColor = (status: string) => {
//   switch (status) {
//     case 'Paid':
//       return '#4CAF50';
//     case 'Unpaid':
//       return '#F44336';
//     case 'Pending':
//       return '#FF9800';
//     default:
//       return '#2196F3';
//   }
// };

// interface CustomerBillCardProps {
//   customer: Customer;
//   onPressBillIcon: (customer: Customer) => void;
// }

// const CustomerBillCard = ({ customer, onPressBillIcon }: CustomerBillCardProps) => (
//   <TouchableOpacity style={styles.card}>
//     <View style={[styles.statusBorder, { backgroundColor: getStatusColor(customer.status) }]} />
//     <View style={styles.cardContent}>
//       <View style={styles.leftContent}>
//         <Text style={styles.customerName}>{customer.name}</Text>
//         <Text style={styles.customerInfo}>Customer ID | {customer.id}</Text>
//         <Text style={styles.customerInfo}>Contact: {customer.contact}</Text>
//       </View>
//       <View style={styles.rightContent}>
//         <Text style={[styles.statusText, { color: getStatusColor(customer.status) }]}>
//           {customer.status}
//         </Text>
//         <TouchableOpacity onPress={() => onPressBillIcon(customer)} style={styles.billIconContainer}>
//           <Feather name="file-text" size={24} color={COLORS.primary} />
//         </TouchableOpacity>
//       </View>
//     </View>
//   </TouchableOpacity>
// );

// export const BillsScreen = ({ navigation }: BillsScreenProps) => {
//   const [searchQuery, setSearchQuery] = useState('');

//   const filteredCustomers = useMemo(() => {
//     return DUMMY_CUSTOMERS.filter(customer =>
//       customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
//       customer.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
//       customer.contact.toLowerCase().includes(searchQuery.toLowerCase())
//     );
//   }, [searchQuery]);

//   const handlePressBillIcon = (customer: Customer) => {
//     Alert.alert(
//       'View Bills',
//       `Navigate to bills for ${customer.name} (${customer.id})`,
//       [
//         { text: 'OK', onPress: () => console.log('OK Pressed') },
//       ],
//     );
//     // In a real app, you would navigate to a detailed bills screen for this customer
//     // navigation.navigate('CustomerBillsDetail', { customerId: customer.id });
//   };

//   return (
//     <SafeAreaView style={styles.safeArea}>
//       <View style={styles.container}>
//         <Text style={styles.title}>Customer Bills</Text>

//         <TextInput
//           style={styles.searchInput}
//           placeholder="Search customers by name, ID, or contact"
//           placeholderTextColor={COLORS.text}
//           value={searchQuery}
//           onChangeText={setSearchQuery}
//         />

//         <ScrollView style={styles.customerList}>
//           {filteredCustomers.map(customer => (
//             <CustomerBillCard
//               key={customer.id}
//               customer={customer}
//               onPressBillIcon={handlePressBillIcon}
//             />
//           ))}
//         </ScrollView>
//       </View>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   safeArea: {
//     flex: 1,
//     backgroundColor: COLORS.white,
//   },
//   container: {
//     flex: 1,
//     paddingHorizontal: 16,
//     paddingTop: 16,
//     backgroundColor: COLORS.background,
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     color: COLORS.text,
//     marginBottom: 20,
//     textAlign: 'center',
//   },
//   searchInput: {
//     width: '100%',
//     height: 50,
//     borderColor: COLORS.primary,
//     borderWidth: 1,
//     borderRadius: 10,
//     paddingHorizontal: 15,
//     marginBottom: 15,
//     color: COLORS.text,
//     backgroundColor: COLORS.white,
//   },
//   customerList: {
//     flex: 1,
//   },
//   card: {
//     backgroundColor: COLORS.white,
//     borderRadius: 12,
//     padding: 16,
//     marginBottom: 16,
//     flexDirection: 'row',
//     shadowColor: '#000',
//     shadowOffset: { width: 0, height: 1 },
//     shadowOpacity: 0.05,
//     shadowRadius: 4,
//     elevation: 2,
//   },
//   statusBorder: {
//     width: 3,
//     borderTopLeftRadius: 3,
//     borderBottomLeftRadius: 3,
//     marginRight: 16,
//   },
//   cardContent: {
//     flex: 1,
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//   },
//   leftContent: {
//     flex: 1,
//   },
//   rightContent: {
//     flexDirection: 'row',
//     alignItems: 'center',
//   },
//   customerName: {
//     fontSize: 16,
//     fontWeight: 'bold',
//     color: COLORS.text,
//   },
//   customerInfo: {
//     fontSize: 13,
//     color: COLORS.gray,
//     marginTop: 4,
//   },
//   statusText: {
//     fontSize: 13,
//     fontWeight: '600',
//     marginRight: 10,
//   },
//   billIconContainer: {
//     padding: 8,
//   },
//   paid: {
//     color: '#4CAF50',
//   },
//   unpaid: {
//     color: '#F44336',
//   },
//   pending: {
//     color: '#FF9800',
//   },
// });


import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, TextInput } from 'react-native';
import Feather from 'react-native-vector-icons/Feather';

const customers = [
  { name: 'John Doe', id: '#CST1023', contact: '+91 9876543210', status: 'Paid' },
  { name: 'Jane Smith', id: '#CST1024', contact: '+91 9876543211', status: 'Unpaid' },
  { name: 'Peter Jones', id: '#CST1025', contact: '+91 9876543212', status: 'Pending' },
  { name: 'Mary Johnson', id: '#CST1026', contact: '+91 9876543213', status: 'Paid' },
  { name: 'David Williams', id: '#CST1027', contact: '+91 9876543214', status: 'Unpaid' },
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Paid':
      return '#4CAF50';
    case 'Unpaid':
      return '#F44336';
    case 'Pending':
      return '#FF9800';
    default:
      return '#2196F3';
  }
};

const CustomerCard = ({
  customer,
  onPress,
  onIconPress,
}: {
  customer: any;
  onPress: () => void;
  onIconPress: () => void;
}) => (
  <TouchableOpacity style={styles.card} onPress={onPress}>
    <View style={[styles.statusBorder, { backgroundColor: getStatusColor(customer.status) }]} />
    <View style={styles.cardContent}>
      <View style={styles.leftContent}>
        <Text style={styles.customerName}>{customer.name}</Text>
        <Text style={styles.customerInfo}>Customer ID | {customer.id}</Text>
        <Text style={styles.customerInfo}>Contact: {customer.contact}</Text>
      </View>
      <View style={styles.rightContent}>
        {/* ✅ separate icon press */}
        <TouchableOpacity onPress={onIconPress}>
          <Feather name="file-text" size={18} color="#1E73B8" style={{ marginBottom: 6 }} />
        </TouchableOpacity>
        <Text style={[styles.statusText, { color: getStatusColor(customer.status) }]}>
          {customer.status}
        </Text>
      </View>
    </View>
  </TouchableOpacity>
);

export const BillsScreen = ({ navigation, route }: { navigation: any; route: any }) => {
  const [filter, setFilter] = useState(route?.params?.filter || 'All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCustomers = useMemo(() => {
    let list = customers;
    if (filter !== 'All') {
      list = list.filter((c) => c.status === filter);
    }
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.contact.toLowerCase().includes(q) ||
          c.id.toLowerCase().includes(q)
      );
    }
    return list;
  }, [filter, searchQuery]);

  const handleCustomerPress = (customer: any) => {
    navigation.navigate('Details', { customer });
  };

  const handleSearchIconPress = () => {
    navigation.navigate('StatementPeriodSelection');
  };

  return (
    <View style={styles.container}>
      {/* 🔍 Search bar */}
      <View style={styles.searchContainer}>
        <TouchableOpacity onPress={handleSearchIconPress}>
          <Feather name="search" size={18} color="#6B6B6B" style={{ marginRight: 8 }} />
        </TouchableOpacity>
        <TextInput
          placeholder="Search by name, contact or ID"
          value={searchQuery}
          onChangeText={setSearchQuery}
          style={styles.searchInput}
        />
      </View>

      {/* Filters */}
      <View style={styles.filterContainer}>
        {['All', 'Paid', 'Pending'].map((status) => (
          <TouchableOpacity
            key={status}
            style={[styles.filterTab, filter === status && styles.activeTab]}
            onPress={() => setFilter(status)}
          >
            <Text style={[styles.filterText, filter === status && styles.activeFilterText]}>
              {status}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Customer list */}
      <FlatList
        data={filteredCustomers}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <CustomerCard
            customer={item}
            onPress={() => handleCustomerPress(item)}
            onIconPress={() => navigation.navigate('StatementPeriodSelection')}
          />
        )}
        ListEmptyComponent={
          <Text style={{ textAlign: 'center', marginTop: 40, color: '#999' }}>
            No customers found
          </Text>
        }
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
    backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#1C1C1C',
  },
  filterContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  filterTab: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: '#F0F0F0',
  },
  activeTab: {
    backgroundColor: '#1E73B8',
  },
  filterText: {
    color: '#6B6B6B',
  },
  activeFilterText: {
    color: '#FFFFFF',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statusBorder: {
    width: 3,
    borderTopLeftRadius: 3,
    borderBottomLeftRadius: 3,
    marginRight: 16,
  },
  cardContent: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leftContent: {
    flex: 1,
  },
  rightContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  customerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1C1C1C',
  },
  customerInfo: {
    fontSize: 13,
    color: '#6B6B6B',
    marginTop: 4,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
});


