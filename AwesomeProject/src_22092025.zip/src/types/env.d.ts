declare module '@env' {
  export const API_URL: string;
}
