export const STRINGS = {
  home_title: 'Home Screen',
  details_title: 'Details Screen',
  go_to_details: 'Go to Details',
};
