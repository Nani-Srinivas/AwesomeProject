import {create} from 'zustand';
import {storageService} from '../services/storageService';
import {secureStorageService} from '../services/secureStorageService';

interface UserState {
  user: {name: string} | null;
  authToken: string | null;
  setUser: (user: {name: string}) => void;
  setAuthToken: (token: string) => void;
  logout: () => void;
  checkAuth: () => Promise<void>;
}

export const useUserStore = create<UserState>((set, get) => ({
  user: storageService.getItem('user'),
  authToken: null,
  setUser: user => {
    storageService.setItem('user', user);
    set({user});
  },
  setAuthToken: token => {
    secureStorageService.saveAuthToken(token);
    set({authToken: token});
  },
  logout: () => {
    storageService.removeItem('user');
    secureStorageService.clearAuthToken();
    set({user: null, authToken: null});
  },
  checkAuth: async () => {
    const token = await secureStorageService.getAuthToken();
    if (token) {
      set({authToken: token});
      // In a real app, you might also fetch the user profile here using the token
      // For now, we'll just restore the token to the state
      const user = get().user; // Keep existing user if already there
      if (!user) {
        // Or fetch from an endpoint
      }
    }
  },
}));