// Add any utility functions here.
// For example, a function to format dates, validate emails, etc.

export const formatDate = (date: Date) => {
  // implementation
  return date.toLocaleDateString();
};
