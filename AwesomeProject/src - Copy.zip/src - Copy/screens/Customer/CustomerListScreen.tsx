import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

const customers = [
  {
    name: 'John Doe',
    id: '#CST1023',
    contact: '+91 9876543210',
    status: 'Paid',
  },
  {
    name: 'Jane Smith',
    id: '#CST1024',
    contact: '+91 9876543211',
    status: 'Unpaid',
  },
  {
    name: 'Peter Jones',
    id: '#CST1025',
    contact: '+91 9876543212',
    status: 'Pending',
  },
  {
    name: 'Mary Johnson',
    id: '#CST1026',
    contact: '+91 9876543213',
    status: 'Paid',
  },
  {
    name: 'David Williams',
    id: '#CST1027',
    contact: '+91 9876543214',
    status: 'Unpaid',
  },
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Paid':
      return '#4CAF50';
    case 'Unpaid':
      return '#F44336';
    case 'Pending':
      return '#FF9800';
    default:
      return '#2196F3';
  }
};

const CustomerCard = ({ customer, onPress }: { customer: any, onPress: () => void }) => (
  <TouchableOpacity style={styles.card} onPress={onPress}>
    <View style={[styles.statusBorder, { backgroundColor: getStatusColor(customer.status) }]} />
    <View style={styles.cardContent}>
      <View style={styles.leftContent}>
        <Text style={styles.customerName}>{customer.name}</Text>
        <Text style={styles.customerInfo}>Customer ID | {customer.id}</Text>
        <Text style={styles.customerInfo}>Contact: {customer.contact}</Text>
      </View>
      <View style={styles.rightContent}>
        <Text style={[styles.statusText, { color: getStatusColor(customer.status) }]}>
          {customer.status}
        </Text>
      </View>
    </View>
  </TouchableOpacity>
);

export const CustomerListScreen = ({ navigation, route }: { navigation: any, route: any }) => {
  const [filter, setFilter] = useState(route.params?.filter || 'All');

  const filteredCustomers = useMemo(() => {
    if (filter === 'All') {
      return customers;
    }
    return customers.filter((customer) => customer.status === filter);
  }, [filter]);

  const handleCustomerPress = (customer: any) => {
    navigation.navigate('Details', { customer });
  };

  return (
    <View style={styles.container}>
      <View style={styles.filterContainer}>
        <TouchableOpacity style={[styles.filterTab, filter === 'All' && styles.activeTab]} onPress={() => setFilter('All')}>
          <Text style={[styles.filterText, filter === 'All' && styles.activeFilterText]}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.filterTab, filter === 'Paid' && styles.activeTab]} onPress={() => setFilter('Paid')}>
          <Text style={[styles.filterText, filter === 'Paid' && styles.activeFilterText]}>Paid</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.filterTab, filter === 'Pending' && styles.activeTab]} onPress={() => setFilter('Pending')}>
          <Text style={[styles.filterText, filter === 'Pending' && styles.activeFilterText]}>Pending</Text>
        </TouchableOpacity>
      </View>
      <ScrollView>
        {filteredCustomers.map((customer) => (
          <CustomerCard key={customer.id} customer={customer} onPress={() => handleCustomerPress(customer)} />
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
    backgroundColor: '#FFFFFF',
  },
  filterContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  filterTab: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: '#F0F0F0',
  },
  activeTab: {
    backgroundColor: '#1E73B8',
  },
  filterText: {
    color: '#6B6B6B',
  },
  activeFilterText: {
    color: '#FFFFFF',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statusBorder: {
    width: 3,
    borderTopLeftRadius: 3,
    borderBottomLeftRadius: 3,
    marginRight: 16,
  },
  cardContent: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leftContent: {
    flex: 1,
  },
  rightContent: {
    justifyContent: 'center',
  },
  customerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1C1C1C',
  },
  customerInfo: {
    fontSize: 13,
    color: '#6B6B6B',
    marginTop: 4,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
  },
});
