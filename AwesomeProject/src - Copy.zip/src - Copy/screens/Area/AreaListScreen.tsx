import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { COLORS } from '../../constants/colors';
import { AddAreaModal } from '../../components/area/AddAreaModal'; // Will create this next

const areas = [
  {
    name: 'Downtown',
    id: '#AREA001',
    pincode: '10001',
    status: 'Active',
  },
  {
    name: 'Uptown',
    id: '#AREA002',
    pincode: '10002',
    status: 'Inactive',
  },
  {
    name: 'Midtown',
    id: '#AREA003',
    pincode: '10003',
    status: 'Active',
  },
  {
    name: 'Westside',
    id: '#AREA004',
    pincode: '10004',
    status: 'Active',
  },
  {
    name: 'Eastside',
    id: '#AREA005',
    pincode: '10005',
    status: 'Inactive',
  },
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Active':
      return '#4CAF50'; // Green
    case 'Inactive':
    return '#F44336'; // Red
    default:
      return COLORS.primary; // Default blue
  }
};

const AreaCard = ({ area, onPress }: { area: any, onPress: () => void }) => (
  <TouchableOpacity style={styles.card} onPress={onPress}>
    <View style={[styles.statusBorder, { backgroundColor: getStatusColor(area.status) }]} />
    <View style={styles.cardContent}>
      <View style={styles.leftContent}>
        <Text style={styles.areaName}>{area.name}</Text>
        <Text style={styles.areaInfo}>ID | {area.id}</Text>
        <Text style={styles.areaInfo}>Pincode: {area.pincode}</Text>
      </View>
      <View style={styles.rightContent}>
        <Text style={[styles.statusText, { color: getStatusColor(area.status) }]}>
          {area.status}
        </Text>
      </View>
    </View>
  </TouchableOpacity>
);

export const AreaListScreen = ({ navigation: _navigation, route }: { navigation: any, route: any }) => {
  const [filter, setFilter] = useState(route.params?.filter || 'All');
  const [isModalVisible, setModalVisible] = useState(false);

  const filteredAreas = useMemo(() => {
    if (filter === 'All') {
      return areas;
    }
    return areas.filter((area) => area.status === filter);
  }, [filter]);

  const handleAreaPress = (area: any) => {
    console.log('Area Pressed:', area);
  };

  const handleAddArea = useCallback(() => {
    setModalVisible(true);
  }, []);

  const onAddArea = useCallback((name: string, pincode: string) => {
    console.log('New Area:', { name, pincode });
    // Here you would typically add the new area to your state or make an API call
    setModalVisible(false);
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.filterContainer}>
        <TouchableOpacity style={[styles.filterTab, filter === 'All' && styles.activeTab]} onPress={() => setFilter('All')}>
          <Text style={[styles.filterText, filter === 'All' && styles.activeFilterText]}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.filterTab, filter === 'Active' && styles.activeTab]} onPress={() => setFilter('Active')}>
          <Text style={[styles.filterText, filter === 'Active' && styles.activeFilterText]}>Active</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.filterTab, filter === 'Inactive' && styles.activeTab]} onPress={() => setFilter('Inactive')}>
          <Text style={[styles.filterText, filter === 'Inactive' && styles.activeFilterText]}>Inactive</Text>
        </TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        {filteredAreas.map((area) => (
          <AreaCard key={area.id} area={area} onPress={() => handleAreaPress(area)} />
        ))}
      </ScrollView>

      {/* Floating Action Button */}
      <TouchableOpacity
        style={styles.fab}
        onPress={handleAddArea}
      >
        <Text style={styles.fabIcon}>+</Text>
      </TouchableOpacity>

      <AddAreaModal
        isVisible={isModalVisible}
        onClose={() => setModalVisible(false)}
        onAddArea={onAddArea}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
    backgroundColor: COLORS.white,
  },
  filterContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  filterTab: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: COLORS.background,
  },
  activeTab: {
    backgroundColor: COLORS.primary,
  },
  filterText: {
    color: COLORS.text,
  },
  activeFilterText: {
    color: COLORS.white,
  },
  scrollViewContent: {
    paddingBottom: 80, // To make space for the FAB
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    shadowColor: COLORS.text,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statusBorder: {
    width: 3,
    borderTopLeftRadius: 3,
    borderBottomLeftRadius: 3,
    marginRight: 16,
  },
  cardContent: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leftContent: {
    flex: 1,
  },
  rightContent: {
    justifyContent: 'center',
  },
  areaName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  areaInfo: {
    fontSize: 13,
    color: COLORS.text,
    marginTop: 4,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
  },
  fab: {
    position: 'absolute',
    width: 56,
    height: 56,
    alignItems: 'center',
    justifyContent: 'center',
    right: 20,
    bottom: 20,
    backgroundColor: COLORS.primary,
    borderRadius: 28,
    elevation: 8,
    shadowColor: COLORS.text,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  fabIcon: {
    fontSize: 24,
    color: COLORS.white,
  },
});
