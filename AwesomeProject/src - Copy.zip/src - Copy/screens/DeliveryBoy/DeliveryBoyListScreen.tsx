import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { COLORS } from '../../constants/colors';
import { AddDeliveryBoyModal } from '../../components/deliveryBoy/AddDeliveryBoyModal';

const deliveryBoys = [
  {
    name: 'Rahul Sharma',
    id: '#DB1001',
    contact: '+91 9988776655',
    status: 'Active',
  },
  {
    name: 'Priya Singh',
    id: '#DB1002',
    contact: '+91 9977665544',
    status: 'Inactive',
  },
  {
    name: 'Amit Kumar',
    id: '#DB1003',
    contact: '+91 9966554433',
    status: 'On-Duty',
  },
  {
    name: 'Sneha Gupta',
    id: '#DB1004',
    contact: '+91 9955443322',
    status: 'Active',
  },
  {
    name: 'Vikas Yadav',
    id: '#DB1005',
    contact: '+91 9944332211',
    status: 'Inactive',
  },
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Active':
      return '#4CAF50'; // Green
    case 'Inactive':
    return '#F44336'; // Red
    case 'On-Duty':
      return '#FF9800'; // Orange
    default:
      return COLORS.primary; // Default blue
  }
};

const DeliveryBoyCard = ({ deliveryBoy, onPress }: { deliveryBoy: any, onPress: () => void }) => (
  <TouchableOpacity style={styles.card} onPress={onPress}>
    <View style={[styles.statusBorder, { backgroundColor: getStatusColor(deliveryBoy.status) }]} />
    <View style={styles.cardContent}>
      <View style={styles.leftContent}>
        <Text style={styles.deliveryBoyName}>{deliveryBoy.name}</Text>
        <Text style={styles.deliveryBoyInfo}>ID | {deliveryBoy.id}</Text>
        <Text style={styles.deliveryBoyInfo}>Contact: {deliveryBoy.contact}</Text>
      </View>
      <View style={styles.rightContent}>
        <Text style={[styles.statusText, { color: getStatusColor(deliveryBoy.status) }]}>
          {deliveryBoy.status}
        </Text>
      </View>
    </View>
  </TouchableOpacity>
);

export const DeliveryBoyListScreen = ({ navigation: _navigation, route }: { navigation: any, route: any }) => {
  const [filter, setFilter] = useState(route.params?.filter || 'All');
  const [isModalVisible, setModalVisible] = useState(false);

  const filteredDeliveryBoys = useMemo(() => {
    if (filter === 'All') {
      return deliveryBoys;
    }
    return deliveryBoys.filter((deliveryBoy) => deliveryBoy.status === filter);
  }, [filter]);

  const handleDeliveryBoyPress = (deliveryBoy: any) => {
    // Navigate to details screen or show bottom sheet for editing
    console.log('Delivery Boy Pressed:', deliveryBoy);
  };

  const handleAddDeliveryBoy = useCallback(() => {
    setModalVisible(true);
  }, []);

  const onAddDeliveryBoy = useCallback((name: string, contact: string) => {
    console.log('New Delivery Boy:', { name, contact });
    // Here you would typically add the new delivery boy to your state or make an API call
    setModalVisible(false);
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.filterContainer}>
        <TouchableOpacity style={[styles.filterTab, filter === 'All' && styles.activeTab]} onPress={() => setFilter('All')}>
          <Text style={[styles.filterText, filter === 'All' && styles.activeFilterText]}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.filterTab, filter === 'Active' && styles.activeTab]} onPress={() => setFilter('Active')}>
          <Text style={[styles.filterText, filter === 'Active' && styles.activeFilterText]}>Active</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.filterTab, filter === 'Inactive' && styles.activeTab]} onPress={() => setFilter('Inactive')}>
          <Text style={[styles.filterText, filter === 'Inactive' && styles.activeFilterText]}>Inactive</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.filterTab, filter === 'On-Duty' && styles.activeTab]} onPress={() => setFilter('On-Duty')}>
          <Text style={[styles.filterText, filter === 'On-Duty' && styles.activeFilterText]}>On-Duty</Text>
        </TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        {filteredDeliveryBoys.map((deliveryBoy) => (
          <DeliveryBoyCard key={deliveryBoy.id} deliveryBoy={deliveryBoy} onPress={() => handleDeliveryBoyPress(deliveryBoy)} />
        ))}
      </ScrollView>

      {/* Floating Action Button */}
      <TouchableOpacity
        style={styles.fab}
        onPress={handleAddDeliveryBoy}
      >
        <Text style={styles.fabIcon}>+</Text>
      </TouchableOpacity>

      <AddDeliveryBoyModal
        isVisible={isModalVisible}
        onClose={() => setModalVisible(false)}
        onAddDeliveryBoy={onAddDeliveryBoy}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
    backgroundColor: COLORS.white,
  },
  filterContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  filterTab: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: COLORS.background,
  },
  activeTab: {
    backgroundColor: COLORS.primary,
  },
  filterText: {
    color: COLORS.text,
  },
  activeFilterText: {
    color: COLORS.white,
  },
  scrollViewContent: {
    paddingBottom: 80, // To make space for the FAB
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    shadowColor: COLORS.text,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statusBorder: {
    width: 3,
    borderTopLeftRadius: 3,
    borderBottomLeftRadius: 3,
    marginRight: 16,
  },
  cardContent: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leftContent: {
    flex: 1,
  },
  rightContent: {
    justifyContent: 'center',
  },
  deliveryBoyName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  deliveryBoyInfo: {
    fontSize: 13,
    color: COLORS.text,
    marginTop: 4,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
  },
  fab: {
    position: 'absolute',
    width: 56,
    height: 56,
    alignItems: 'center',
    justifyContent: 'center',
    right: 20,
    bottom: 20,
    backgroundColor: COLORS.primary,
    borderRadius: 28,
    elevation: 8,
    shadowColor: COLORS.text,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  fabIcon: {
    fontSize: 24,
    color: COLORS.white,
  },
});
