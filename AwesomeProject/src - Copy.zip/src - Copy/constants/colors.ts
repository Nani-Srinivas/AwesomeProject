export const COLORS = {
  primary: '#6200ee',
  accent: '#03dac4',
  background: '#f6f6f6',
  text: '#000000',
  white: '#ffffff',
};
