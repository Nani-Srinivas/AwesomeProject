import axios, { AxiosError } from 'axios';

import { Alert } from 'react-native';
import { secureStorageService } from '../services/secureStorageService';
import { useUserStore } from '../store/userStore';

const axiosInstance = axios.create({
  baseURL: process.env.API_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add the auth token to headers
axiosInstance.interceptors.request.use(
  async config => {
    const token = await secureStorageService.getAuthToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  },
);

// Response interceptor to handle global errors
axiosInstance.interceptors.response.use(
  response => {
    // Any status code that lie within the range of 2xx cause this function to trigger
    return response;
  },
  (error: AxiosError) => {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    if (error.response && error.response.status === 401) {
      // Token is invalid or expired
      // Use getState() to call action outside of a React component
      const { authToken } = useUserStore.getState();
      if (authToken) {
        // Only show alert and logout if there was a token to begin with
        Alert.alert('Session Expired', 'You have been logged out. Please log in again.');
        useUserStore.getState().logout();
      }
    }

    // You can handle other common errors here (e.g., 500, 404)

    return Promise.reject(error);
  },
);

export default axiosInstance;