import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { MainStackParamList } from '../types';
import { HomeScreen } from '../../screens/Home/HomeScreen';
import { DetailsScreen } from '../../screens/Details/DetailsScreen';
import { DashboardScreen } from '../../screens/Dashboard/DashboardScreen';
import { CustomerListScreen } from '../../screens/Customer/CustomerListScreen';
import { CalendarScreen } from '../../screens/Calendar/CalendarScreen';


import { DeliveryBoyListScreen } from '../../screens/DeliveryBoy/DeliveryBoyListScreen';
import { AreaListScreen } from '../../screens/Area/AreaListScreen';
import { SideMenu } from '../../components/common/SideMenu';


const Stack = createNativeStackNavigator<MainStackParamList>();

export const MainStack = () => {
  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen name="Dashboard" component={DashboardScreen} options={{ headerShown: false }}/>
      <Stack.Screen name="Home" options={{ headerShown: false }}>
        {(props) => <HomeScreen setIsLoggedIn={function (isLoggedIn: boolean): void {
          throw new Error('Function not implemented.');
        } } {...props} />}
      </Stack.Screen>
      <Stack.Screen name="Details" component={DetailsScreen} />
      <Stack.Screen name="CustomerList" component={CustomerListScreen} options={{ title: 'Customers' }} />
      <Stack.Screen name="DeliveryBoyList" component={DeliveryBoyListScreen} options={{ title: 'Delivery Boys' }} />
      <Stack.Screen name="AreaList" component={AreaListScreen} options={{ title: 'Areas' }} />
      <Stack.Screen name="Calendar" component={CalendarScreen} options={{ title: 'Calendar' }} />
      <Stack.Screen name="SideMenu" component={SideMenu} options={ { headerShown: false }} />

    </Stack.Navigator>
  );
};
